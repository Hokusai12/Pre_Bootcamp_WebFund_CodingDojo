childHeight = 48;

function displayIfChildIsAbleToRideTheRollercoaster() {
    if(childHeight > 52) {
        console.log("Get on that ride, kiddo!");
    } else {
        console.log("Sorry kiddo. Maybe next year.");
    }
}

displayIfChildIsAbleToRideTheRollercoaster();